/**
   This package houses annotations specific  a JNI binding to the SQLite3 C API.
*/
package org.sqlite.jni.annotation;
